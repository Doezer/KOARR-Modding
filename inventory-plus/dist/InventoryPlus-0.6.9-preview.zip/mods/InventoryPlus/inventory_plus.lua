-- Inventory Plus 0.6.9 (native bridge token stays 0.6.0): native category-scoped search, name sorting and provisional damage/armor sorting.
local function bootstrap()
local G=_G
local previous=rawget(G,'InventoryPlus')
if previous and previous.enabled then previous.attach();return previous end
local function log(message)print('[InventoryPlus] '..message)end
local N=rawget(G,'InventoryPlusNative')
if type(N)~='table' or type(N.self_test)~='function' or type(N.poll)~='function' or type(N.idle)~='function' or type(N.fold)~='function' or type(N.item_name)~='function' then
 log('Native inventory helper unavailable (unsupported game build or incomplete install); no inventory changes installed.');return false
end
local M=rawget(G,'InventoryPlusModel')
if type(M)~='table' then log('Row model unavailable; no inventory hooks installed.');return false end
local S={enabled=true,version='0.6.9-preview',hooks={},query='',editing=false,closing=false,ready=false,order='native',matched=0,total=0}
G.InventoryPlus=S
local nav=rawget(G,'InventoryPlusNavigationV2')
local tabs=nav and nav.create(S,log,N)
local function update_tabs()
 if tabs then
  local ok,err=pcall(tabs.update)
  if not ok then tabs.detach();tabs.failed=true;log('Tabs stopped: '..tostring(err))end
 end
end
local function pack(...)return {n=select('#',...),...}end
local function returns(t)return unpack(t,1,t.n)end
local function wrap(module,name,make)
 if type(module)~='table' or type(module[name])~='function' then return false end
 for _,h in ipairs(S.hooks)do if h.module==module and h.name==name then return true end end
 local original=module[name];local replacement=make(original)
 module[name]=replacement
 S.hooks[#S.hooks+1]={module=module,name=name,original=original,replacement=replacement}
 return true
end
-- Numeric sort sources (all high to low). dmg/arm read the game's native 14-slot tables
-- through the helper; req/val call ACTOR getters exactly as other working mods do
-- (single item handle, numeric result). Which values the item card shows is checked
-- with Ctrl+D. Confirmed against cards: damage = direct rows + damage over time, armor = slot 0 scaled.
local WEAPONS={[2627341]=true,[2010694]=true}
local ARMOR={[1070770]=true}
local GEAR={[2627341]=true,[2010694]=true,[1070770]=true,[6689260]=true}
local ALL={[2627341]=true,[2010694]=true,[1070770]=true,[6689260]=true,[7304644]=true,[911336]=true,[607556]=true}
local STATS={
 dmg={reader='card',label='Dmg',slots=WEAPONS}, -- the card headline: direct damage rows + damage over time
 arm={kind='a',index=0,scaled=1,label='Armor',slots=ARMOR},
 req={getters={'get_might_requirement','get_finesse_requirement','get_intellect_requirement','get_level_requirement'},label='Req',slots=GEAR},
 val={getter='get_item_cost',label='Value',slots=ALL},
}
local STAT_ORDER={'dmg','arm','req','val'}
-- The card headline (58 = 35 Lightning + 23 Shocking/5s; 72 = 25 + 16 + 31 Burning/3s; 101 = 74 + 27)
-- is the direct damage rows (mod_b, with bonuses) plus the damage-over-time rows (base), read with
-- the same character_data functions the card and other working mods use.
-- character_data.get_item_damage_by_type skips an element whose own amount is 0, so a buff-added
-- element (6 Lightning on Charged Faeblades) never shows there. The with-bonuses per-type readers
-- (as Transmog calls them) see every type, direct and over time.
local function damage_types()
 local cd=rawget(G,'character_data')
 local types=type(cd)=='table' and cd.m_damage_types
 return type(types)=='table' and #types>0 and #types or 14
end
local function card_damage(handle,detail)
 local A=rawget(G,'ACTOR')
 if type(A)~='table' or type(A.get_weapon_damage)~='function' then return nil end
 local total,names
 local cd=rawget(G,'character_data');names=type(cd)=='table' and cd.m_damage_types
 for index=0,damage_types()-1 do
  local ok,direct=pcall(A.get_weapon_damage,handle,index,true);direct=ok and tonumber(direct)
  local over=0
  if type(A.get_weapon_dot_damage)=='function' then
   local okd,value=pcall(A.get_weapon_dot_damage,handle,index,true);over=okd and tonumber(value) or 0
  end
  if direct then
   total=(total or 0)+direct+over
   if detail and (direct>0 or over>0) then detail[#detail+1]=tostring(type(names)=='table' and names[index+1] or index)..' '..direct..'+'..over end
  end
 end
 return total
end
local function stat_available(order,slot)
 local d=STATS[order]
 if not d or not d.slots[slot] then return false end
 if d.reader=='card' then
  local A=rawget(G,'ACTOR')
  return type(A)=='table' and type(A.get_weapon_damage)=='function'
 end
 if d.getter or d.getters then
  local A=rawget(G,'ACTOR')
  if type(A)~='table' then return false end
  for _,name in ipairs(d.getters or {d.getter})do if type(A[name])~='function' then return false end end
  return true
 end
 return type(N.stat)=='function' and type(N.has_stats)=='function' and tostring(N.has_stats())=='1'
end
local function stat_orders_for(slot)
 local list={}
 for _,order in ipairs(STAT_ORDER)do if stat_available(order,slot)then list[#list+1]=order end end
 return list
end
local function stat_reader(order)
 local d=STATS[order]
 if d.reader=='card' then return card_damage end
 if d.getter or d.getters then
  local A=rawget(G,'ACTOR');local names=d.getters or {d.getter}
  -- A single number per item; an item shows at most one requirement, so take the largest.
  return function(handle)
   local best
   for _,name in ipairs(names)do
    local ok,value=pcall(A[name],handle);value=ok and tonumber(value)
    if value and (not best or value>best)then best=value end
   end
   return best
  end
 end
 local function read(handle,index)
  local ok,text=pcall(N.stat,handle,string.format('%s%02d%d',d.kind,index,d.scaled))
  if ok then return tonumber(text)end
 end
 if d.sum then
  -- The card shows the total over every damage type; unreadable only if no slot answers.
  return function(handle)
   local total
   for index=0,13 do
    local value=read(handle,index)
    if value then total=(total or 0)+value end
   end
   return total
  end
 end
 return function(handle)return read(handle,d.index)end
end
local reminder,scope
-- The footer shares its row with native buttons; text past this width slides under them.
local HINT_WIDTH=34
local function width(text)
 local n=0
 for i=1,#text do local b=string.byte(text,i);if b<128 or b>=192 then n=n+1 end end
 return n
end
local function hint()
 local sort=S.order=='az' and 'A-Z' or S.order=='za' and 'Z-A' or (STATS[S.order] and STATS[S.order].label) or ''
 if S.query~='' then
  local counts=tostring(S.matched)..'/'..tostring(S.total)
  local tail=(sort~='' and ' '..sort or '')..' | Esc: Clear'
  local limit,text=6
  repeat
   text=(S.matched==0 and 'No match' or M.short(S.query,limit))..' '..counts..tail
   limit=limit-1
  until width(text)<=HINT_WIDTH or limit<1
  return text
 end
 if tabs and #tabs.windows>0 then
  return sort~='' and (sort..' | Ctrl+1-7 Tabs | Ctrl+F/S') or 'Ctrl+1-7 Tabs | Ctrl+F/S Find/Sort'
 end
 return sort~='' and (sort..' | Ctrl+F: Find | Ctrl+S') or 'Ctrl+F: Find | Ctrl+S: Sort'
end
S.footer_text=hint -- exposed so tests can bound the width
local function update_hint()
 if reminder and S.enabled then reminder.write(reminder.label,hint())end
end
local function restore_hint()
 if reminder then local old=reminder;reminder=nil;old.setter(returns(old.args))end
end
local function capture(original,...)
 local W=rawget(G,'WINDOW')
 if type(W)~='table' or type(W.set_label_text)~='function' then return original(...)end
 local changed,captured={},nil
 local write=W.set_label_text
 for _,name in ipairs({'set_label_text','set_label_text_formatted','set_label_text_no_loc_fix_up','set_label_text_with_built_string'})do
  local setter=W[name]
  if type(setter)=='function' then
   local replacement=function(...)
    local args=pack(...);local result=pack(setter(...))
    if args[1] then captured={label=args[1],write=write,setter=setter,args=args}end
    return returns(result)
   end
   W[name]=replacement;changed[#changed+1]={name=name,setter=setter,replacement=replacement}
  end
 end
 local result=pack(pcall(original,...))
 for _,h in ipairs(changed)do if W[h.name]==h.replacement then W[h.name]=h.setter end end
 if not result[1] then error(result[2],0)end
 if captured then reminder=captured;update_hint()end
 return unpack(result,2,result.n)
end
local function available()
 local I,W=rawget(G,'inventory_win'),rawget(G,'WINDOW')
 return S.enabled and type(I)=='table' and I.m_inited and I.m_window
  and type(I.m_button_definitions)=='table' and type(I.m_button_definitions[I.m_selected_slot])=='table'
  and type(I.m_last_set)=='table'
  and type(W)=='table' and type(W.is_visible)=='function' and W.is_visible(I.m_window)
  and (I.m_curr_mode=='replace' or I.m_curr_mode=='pocket')
end
local function ensure_bridge()
 if S.ready then return true end
 local ok,reply=pcall(N.self_test,'InventoryPlus 0.6.0')
 if not ok or reply~='InventoryPlus 0.6.0'then
  if not S.bridge_warning then log('Native version mismatch; replace the complete package.');S.bridge_warning=true end
  return false
 end
 local folded,normalized=pcall(N.fold,'InVeNtOrY PlUs')
 if not folded or normalized~='inventory plus'then
  if not S.bridge_warning then log('Native text normalization failed; search/sort left disabled.');S.bridge_warning=true end
  return false
 end
 S.ready=true;return true
end
local function restore_categories()
 if S.expanded_restore then
  for state,old in pairs(S.expanded_restore)do state.collapsed=old.value end
  S.expanded_restore=nil
 end
end
local function remember_categories(I)
 S.expanded_restore=S.expanded_restore or {}
 if type(I.m_category_status)=='table' then
  for _,state in pairs(I.m_category_status)do
   if type(state)=='table' and not S.expanded_restore[state]then
    S.expanded_restore[state]={value=state.collapsed};state.collapsed=false
   end
  end
 end
end
local function active()return S.query~='' or S.order~='native'end
local function item_name(handle)
 local A=rawget(G,'ACTOR')
 assert(type(A)=='table' and type(A.is_valid)=='function','Item-name API unavailable')
 assert(A.is_valid(handle),'Stale item handle')
 return N.item_name(handle)
end
function S.refresh()
 local I=rawget(G,'inventory_win')
 if type(I)~='table' or type(I.rebuild_list_win)~='function' then return false end
 S.refreshing=true
 local ok,err=pcall(function()
  I.rebuild_list_win()
  if type(I.update_visibility)=='function'then I.update_visibility()end
  if type(I.update_rose)=='function'then I.update_rose()end
 end)
 S.refreshing=false
 if not ok then
  S.query='';S.order='native';restore_categories()
  pcall(I.rebuild_list_win)
  log('View update failed; search/sort disabled: '..tostring(err));update_hint();return false
 end
 update_hint();return true
end
function S.set_query(text)
 if type(text)~='string' or not ensure_bridge()then return false end
 text=M.trim(text)
 if text~='' then remember_categories(rawget(G,'inventory_win'))else restore_categories()end
 S.query=text
 return S.refresh()
end
function S.clear_search()
 if S.query==''then return false end
 return S.set_query('')
end
function S.cycle_sort()
 if not ensure_bridge()then return false end
 local I=rawget(G,'inventory_win')
 local sequence={'native','az','za'}
 if type(I)=='table' then for _,order in ipairs(stat_orders_for(I.m_selected_slot))do sequence[#sequence+1]=order end end
 local at=0;for index,order in ipairs(sequence)do if order==S.order then at=index end end
 S.order=sequence[at%#sequence+1]
 return S.refresh()
end
function S.dump_stats()
 local I,A=rawget(G,'inventory_win'),rawget(G,'ACTOR')
 if not available() or type(N.stats)~='function' or type(I.get_selected_item)~='function' then return false end
 local handle=I.get_selected_item()
 if handle==nil or type(handle)=='string' or type(A)~='table' or type(A.is_valid)~='function' or not A.is_valid(handle) then
  log('Stats: no valid selected item.');return false
 end
 local r=pack(pcall(N.stats,handle))
 if not r[1] or r.n<6 then log('Stats: item has no readable tables.');return false end
 log('Stats: item="'..tostring(r[2])..'" slot='..tostring(I.m_selected_slot)..'; columns are slot indices 0..13')
 log('Stats: damage raw    ='..r[3]);log('Stats: damage scaled ='..r[4])
 log('Stats: armor  raw    ='..r[5]);log('Stats: armor  scaled ='..r[6])
 local detail={};local total=card_damage(handle,detail)
 log('Stats: card damage (direct + over time) = '..tostring(total)..' ['..table.concat(detail,', ')..']; sort keys: damage = card damage, armor = slot '..STATS.arm.index..' (scaled)')
 local A=rawget(G,'ACTOR')
 if type(A)=='table' then
  local function read(name)local f=A[name];if type(f)=='function' then local ok,v=pcall(f,handle);return ok and tostring(v) or 'error' end;return 'n/a' end
  log('Stats: get_item_cost='..read('get_item_cost')..' get_level_requirement='..read('get_level_requirement')..' get_item_level='..read('get_item_level'))
  log('Stats: requirements might='..read('get_might_requirement')..' finesse='..read('get_finesse_requirement')..' intellect='..read('get_intellect_requirement'))
 end
 return true
end
-- The game binds the digits 1 and 2 to equipping the hovered item. While a Ctrl+digit tab chord is
-- held (and until every key is up) the game's own copy of that key event must not reach it,
-- whichever of our frame poll or the game's event is processed first. Back is never swallowed.
local function chord_held()
 if type(N.held)~='function' then return false end
 for index=1,7 do if N.held('Ctrl+'..index)then return true end end
 return false
end
local function chord_active()return S.key_guard==true or chord_held()end
local function shortcuts(action)
 if tabs and (action=='b' or action=='exiting' or action=='exitingshortcut')then tabs.cancel()end
 if not available()then return false end
 local menu=rawget(G,'menu_tools')
 if type(menu)=='table' and type(menu.is_dragging)=='function' and menu.is_dragging()then return false end
 if S.query~='' and type(action)=='string'then
  local key=string.lower(action)
  if key=='b' or key=='exiting' or key=='exitingshortcut'then S.back_guard=true;S.clear_search();return true end
 end
 if tabs then for index=1,7 do if N.poll('Ctrl+'..index)then S.key_guard=true;tabs.select(index,true);return true end end end
 if N.poll('Ctrl+F')then S.open_search();return true end
 if N.poll('Ctrl+S')then S.cycle_sort();return true end
 if N.poll('Ctrl+D')then S.dump_stats();return true end
 return false
end
function S.open_search()
 if not available() or S.editing or S.back_guard or S.navigating then return false end
 local name=rawget(G,'name_win')
 if type(name)~='table' or type(name.launch)~='function' or name.m_inited then return false end
 local tutorial=rawget(G,'tutorial_win')
 if type(tutorial)=='table' and type(tutorial.is_modal_tutorial_active)=='function' and tutorial.is_modal_tutorial_active()then return false end
 local menu=rawget(G,'menu_tools')
 if type(menu)=='table' and type(menu.is_dragging)=='function' and menu.is_dragging()then return false end
 if not ensure_bridge()then log('Keyboard bridge check failed; search disabled.');return false end
 S.editing=true;S.closing=false;S.pending_query=nil
 local callback=function(text,cancelled)
  if not S.editing or S.callback~=name.m_callback then return end
  if not cancelled and type(text)=='string' then S.pending_query=text end
  S.closing=true
  log(cancelled and 'Search cancelled.' or 'Search text accepted.')
 end
 S.callback=callback
 -- Original six-argument name_win contract; it creates/focuses the native modal.
 local ok,err=pcall(name.launch,'Search items',S.query,false,64,callback,false)
 if not ok then
  if name.m_inited and name.m_callback==callback and type(name.cancel_name)=='function' then pcall(name.cancel_name)end
  S.editing=false;S.closing=false;S.callback=nil;S.pending_query=nil
  log('Could not open search: '..tostring(err));return false
 end
 log('Native search dialog requested.');return true
end
function S.attach()
 local I=rawget(G,'inventory_win')
 if type(I)~='table' or type(I.on_update_event)~='function' or type(I.on_window_event)~='function' then return end
 -- A native parent transition can hide the inventory child. Tick navigation
 -- from the still-open ledger so it can finish entering the destination.
 local ledger=rawget(G,'ledger_win')
 wrap(ledger,'on_update_event',function(original)return function(...)
  local result=pack(original(...))
  if S.key_guard and N.idle('InventoryPlus')then S.key_guard=false end
  update_tabs();return returns(result)
 end end)
 -- The ledger sees button events before forwarding them to inventory. Stop
 -- tab events here so native tree hit testing cannot also activate a category.
 wrap(ledger,'on_button_event_selection',function(original)return function(...)
  if S.enabled and tabs and tabs.event(...)then return end
  return original(...)
 end end)
 -- Project fresh native row tables; never change the actor's inventory arrays.
 wrap(I,'get_surplus_inventory',function(original)return function(...)
  if S.enabled and S.view_slot~=I.m_selected_slot then S.view_slot=I.m_selected_slot;S.category_changed=true end
  if S.enabled and STATS[S.order] and not stat_available(S.order,I.m_selected_slot) then
   S.order='az';log('Stat sort does not apply to this category; sorting by name.')
  end
  if not S.enabled or not active()then return original(...)end
  if S.query~=''then remember_categories(I)end
  local changed={}
  if type(I.m_category_status)=='table'then
   for _,state in pairs(I.m_category_status)do
    if type(state)=='table'then changed[#changed+1]={state=state,value=state.collapsed};state.collapsed=false end
   end
  end
  local raw=pack(pcall(original,...))
  for _,old in ipairs(changed)do old.state.collapsed=old.value end
  if not raw[1]then error(raw[2],0)end
  local ok,view=pcall(M.project,raw[2],S.query,S.order,item_name,N.fold,I.m_category_status,STATS[S.order] and stat_reader(S.order) or nil)
  if not ok then
   S.query='';S.order='native';restore_categories()
   log('Search/sort unavailable; showing native list: '..tostring(view))
   return original(...)
  end
  I.m_cur_categories=view.categories;S.matched=view.matched;S.total=view.total
  raw[2]=view.rows
  return unpack(raw,2,raw.n)
 end end)
 wrap(I,'get_selected_item',function(original)return function(...)
  local result=pack(original(...))
  if S.enabled and active() and result[1]~=nil and type(result[1])~='string'then
   local A=rawget(G,'ACTOR')
   if type(A)=='table' and type(A.is_valid)=='function' and not A.is_valid(result[1])then return nil end
  end
  return returns(result)
 end end)
 local function remap_selection()
  local pending=S.rebuild_selection
  if pending and not pending.applied and I.m_list and type(I.m_list.set_selected)=='function'and type(I.m_last_set)=='table'then
   pending.applied=true
   local index=M.selection(I.m_last_set,pending.handle,pending.index)
   if index~=nil then I.m_list:set_selected(index)end
   I.m_mouse_event_received=false;I.m_moused_over_id=nil
  end
 end
 wrap(I,'update_selected_window',function(original)return function(...)
  -- Native rebuild calls this before returning. Select by handle before any
  -- tooltip/card observer can see the item now occupying the old row index.
  if S.enabled then remap_selection()end
  return original(...)
 end end)
 wrap(I,'rebuild_list_win',function(original)return function(...)
  local preserve=S.enabled and (active() or S.refreshing) and S.view_slot==I.m_selected_slot and not S.category_changed
  local pending=preserve and {} or nil
  if pending and I.m_list and type(I.m_list.get_selected)=='function' and type(I.get_selected_item)=='function'then
   pending.index=I.m_list:get_selected();pending.handle=I.get_selected_item()
  end
  local old=S.rebuild_selection;S.rebuild_selection=pending
  local result=pack(pcall(original,...))
  if result[1] and pending and not pending.applied then
   local ok,err=pcall(function()
    remap_selection()
    if type(I.update_selected_window)=='function'then I.update_selected_window(I.m_selected_item_window)end
   end)
   if not ok then result={n=2,false,err}end
  end
  S.rebuild_selection=old
  if not result[1]then error(result[2],0)end
  S.category_changed=false
  update_hint();return unpack(result,2,result.n)
 end end)
 wrap(rawget(G,'ledger_win'),'set_reminder',function(original)return function(...)
  local W=rawget(G,'WINDOW')
  local browsing=not S.window_hidden and available() and I.m_list_wrapper
   and W.is_visible(I.m_list_wrapper)
  if S.enabled and not S.window_hidden and (scope or browsing) then return capture(original,...)end
  reminder=nil;return original(...)
 end end)
 wrap(I,'button_tree_callback',function(original)return function(...)
  local old=scope;scope=S.enabled
  local result=pack(pcall(original,...));scope=old
  if not result[1]then error(result[2],0)end
  return unpack(result,2,result.n)
 end end)
 wrap(I,'on_window_event',function(original)return function(event,...)
  if event=='SHOW'then S.window_hidden=false end
  if S.enabled and (event=='HIDE' or event=='START_CLOSE')then
   S.window_hidden=true
   restore_hint();if tabs then tabs.close()end;if not S.editing and not S.navigating then S.query='';restore_categories()end
  end
  if S.enabled and event=='SHOW' and not S.editing and not S.navigating then S.query='';restore_categories()end
  if S.enabled and event=='SHOW' then N.poll('Ctrl+F');N.poll('Ctrl+S')end
  return original(event,...)
 end end)
 -- Block the ledger's action dispatch before it reaches the native button tree.
 -- name_win's own modal handlers stay active for text, confirmation and cancel.
 wrap(rawget(G,'ledger_win'),'on_inputdeviceaction_event',function(original)return function(window,action,...)
  local back=action=='b' or action=='exiting' or action=='exitingshortcut'
  if S.enabled and tabs and tabs.owns_click() and not back then return end
  if S.enabled and (S.editing or S.back_guard)then return end
  if tabs and (action=='b' or action=='exiting' or action=='exitingshortcut')then tabs.cancel()end
  if shortcuts(action)then return end
  if back and tabs and type(tabs.back)=='function'and tabs.back()then return end
  if S.enabled and not back and chord_active()then return end
  return original(window,action,...)
 end end)
 wrap(I,'handle_input',function(original)return function(input,...)
  local action=type(input)=='table'and input.info
  local back=action=='b' or action=='exiting' or action=='exitingshortcut'
  if S.enabled and tabs and tabs.owns_click() and not back then
   if type(input)=='table'then input.handled=true end;return
  end
  if back and not S.editing and not S.back_guard and tabs and S.query=='' and type(tabs.back)=='function'and tabs.back()then
   if type(input)=='table'then input.handled=true end;return
  end
  if not S.editing and not S.back_guard and shortcuts(type(input)=='table' and input.info)then
   if type(input)=='table'then input.handled=true end;return
  end
  if S.enabled and (S.editing or S.back_guard)then if type(input)=='table'then input.handled=true end;return end
  if S.enabled and not back and chord_active()then if type(input)=='table'then input.handled=true end;return end
  return original(input,...)
 end end)
 for _,name in ipairs({'on_button_event_selection','on_mouse_event_scroll','on_mouse_event_tooltip',
  'handle_template_double_click','handle_drop','start_drag_visuals','equip_selected','unequip_selected',
  'equip_item_to_slot','queue_for_autosell','remove_from_autosell','destroy_selected_item',
  'confirm_destroy_selected_item','confirm_destroy_junk'})do
  local action_name=name
  wrap(I,name,function(original)return function(...)
   if S.enabled and tabs and tabs.owns_click()then return end
   if S.enabled and (S.editing or S.back_guard)then return end
   if S.enabled and chord_active()then return end
   if S.enabled and S.query~='' and action_name=='confirm_destroy_junk'then
    log('Clear search before destroying all junk.');return
   end
   if S.enabled and active() and (action_name=='equip_selected' or action_name=='unequip_selected' or action_name=='destroy_selected_item')
    and type(I.get_selected_item)=='function' and I.get_selected_item()==nil then return end
   if tabs and action_name=='on_button_event_selection' and tabs.event(...)then return end
   return original(...)
  end end)
 end
 wrap(I,'on_update_event',function(original)return function(...)
  if S.enabled and tabs and tabs.owns_click()then
   local ledger=rawget(G,'ledger_win')
   if type(ledger)~='table'or type(ledger.on_update_event)~='function'then update_tabs()end
   return
  end
  if S.enabled and S.back_guard then
   if N.idle('InventoryPlus')then S.back_guard=false end
   return
  end
  -- Defer releasing the guard until the modal is closed and held keys are up.
  -- This prevents Enter/Escape/Space from acting on an inventory item on return.
  if S.enabled and S.closing then
   local name=rawget(G,'name_win')
   if (type(name)~='table' or not name.m_inited) and N.idle('InventoryPlus')then
    S.editing=false;S.closing=false;S.callback=nil
    local query=S.pending_query;S.pending_query=nil
    if query~=nil then S.set_query(query)else update_hint()end
    log('Search closed; '..tostring(S.matched)..'/'..tostring(S.total)..' matching items.')
    return -- consume this update; native inventory resumes on the following one
   end
  end
  if S.enabled and S.editing then return end
  local result=pack(original(...))
  shortcuts()
  local ledger=rawget(G,'ledger_win')
  if type(ledger)~='table' or type(ledger.on_update_event)~='function'then update_tabs()end
  local W=rawget(G,'WINDOW')
  if not S.window_hidden and available() and I.m_list_wrapper and W.is_visible(I.m_list_wrapper)then update_hint()end
  return returns(result)
 end end)
 if not S.announced then S.announced=true;log('Search preview ready. Ctrl+F: find; Ctrl+S: name sort; Esc: clear search.')end
end
function S.detach()
 S.enabled=false
 local name=rawget(G,'name_win')
 if S.editing and type(name)=='table' and name.m_callback==S.callback and name.m_inited and type(name.cancel_name)=='function'then pcall(name.cancel_name)end
 if tabs then tabs.detach()end
 S.editing=false;S.closing=false;S.back_guard=false;S.key_guard=false;S.callback=nil;S.pending_query=nil;S.query='';S.order='native';restore_categories();restore_hint()
 local I=rawget(G,'inventory_win')
 if type(I)=='table'and I.m_inited and I.m_list and type(I.rebuild_list_win)=='function'then pcall(I.rebuild_list_win)end
 for i=#S.hooks,1,-1 do local h=S.hooks[i];if h.module[h.name]==h.replacement then h.module[h.name]=h.original end end
 return true
end
S.attach();return S
end
local ok,result=pcall(bootstrap)
if not ok then
 local partial=rawget(_G,'InventoryPlus')
 if type(partial)=='table'and type(partial.detach)=='function'then pcall(partial.detach)end
 print('[InventoryPlus] Adapter disabled: '..tostring(result));return false
end
return result
